const { default: makeWASocket, useMultiFileAuthState, DisconnectReason } = require('@whiskeysockets/baileys');
const pino = require('pino');
const fs = require('fs');
const path = require('path');

const AUTH_DIR = path.join(__dirname, '..', 'auth');
const BOT_NAME = process.env.BOT_NAME || 'MODIFIER-MD';
const PREFIX = process.env.PREFIX || '!';

async function startBot() {
  fs.mkdirSync(AUTH_DIR, { recursive: true });
  const { state, saveCreds } = await useMultiFileAuthState(AUTH_DIR);
  const sock = makeWASocket({
    auth: state,
    logger: pino({ level: 'silent' }),
    printQRInTerminal: true,
    browser: [BOT_NAME, 'Chrome', '1.0.0']
  });

  sock.ev.on('creds.update', saveCreds);
  sock.ev.on('connection.update', ({ connection, lastDisconnect, qr }) => {
    if (qr) console.log('\nOpen WhatsApp > Linked devices > Link a device and scan the QR shown in this terminal.');
    if (connection === 'open') console.log(`${BOT_NAME} connected successfully.`);
    if (connection === 'close') {
      const code = lastDisconnect?.error?.output?.statusCode;
      if (code !== DisconnectReason.loggedOut) {
        console.log('Connection closed. Reconnecting...');
        setTimeout(() => startBot().catch(console.error), 3000);
      } else {
        console.log('Logged out. Remove the saved auth files and pair again if you want to reconnect.');
      }
    }
  });

  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return;
    for (const msg of messages) {
      if (!msg.message || msg.key.fromMe) continue;
      const jid = msg.key.remoteJid;
      if (!jid || jid === 'status@broadcast') continue;
      const text = msg.message.conversation ||
        msg.message.extendedTextMessage?.text ||
        msg.message.imageMessage?.caption ||
        msg.message.videoMessage?.caption || '';
      if (!text.startsWith(PREFIX)) continue;
      const [commandRaw] = text.slice(PREFIX.length).trim().split(/\s+/);
      const command = (commandRaw || '').toLowerCase();
      let reply;
      if (command === 'ping') reply = 'Pong! MODIFIER-MD is online. ✅';
      else if (command === 'menu' || command === 'help') {
        reply = `*${BOT_NAME} MENU*\n\n${PREFIX}ping — Check whether the bot is online\n${PREFIX}menu — Show this menu\n\nStarter version: more commands can be added later.`;
      }
      if (reply) {
        try { await sock.sendMessage(jid, { text: reply }, { quoted: msg }); }
        catch (err) { console.error('Could not send reply:', err.message); }
      }
    }
  });
}

startBot().catch(err => {
  console.error('Bot failed to start:', err.message || err);
  process.exitCode = 1;
});

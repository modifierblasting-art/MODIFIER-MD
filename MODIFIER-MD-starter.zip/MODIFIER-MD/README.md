# MODIFIER-MD — beginner starter

This is a small, newly written starter project, not a copy of the obfuscated JAWAD-MD source. It currently supports only `!menu`, `!help`, and `!ping` so you can test the connection before adding features.

## Important safety notes
- The bot is **not yet connected or hosted**. You must complete pairing with your own WhatsApp account and choose a host.
- Use an account you control. Linking a bot can expose messages to its code; only run code you trust.
- Never share QR codes, pairing codes, session/auth files, GitHub tokens, or hosting secrets with anyone.
- Keep the `auth/` folder private and never upload it to GitHub. It contains login credentials.
- Unofficial WhatsApp Web automation can stop working or risk account restrictions. Use responsibly; don't spam people.

## Run on a Node.js 20+ computer/server
1. Install dependencies: `npm install`
2. Start: `npm start`
3. Follow the terminal pairing instructions and link only your own account.
4. Send `!menu` or `!ping` to the linked account from another chat to test it.

For hosting, choose a service that supports a continuously running Node.js process and persistent private storage. Do not use a serverless-only host; the WhatsApp connection needs to stay alive. Add `BOT_NAME=MODIFIER-MD` and optionally `PREFIX=!` as environment variables.

## Project files
- `src/index.js` — bot logic
- `package.json` — dependencies and start command
- `auth/` — empty directory for local session data; keep private
